<h2 align="center">Cook blog</h2>







### tools

**stack:**
- Python >= 3.9
- Django >= 3
- sqlite3

## 1



    git clone 

##### 2

    python -m venv venv
    


##### 3

    pip install -r req.txt

##### 4

    python manage.py migrate
    
##### 5

    python manage.py createsuperuser
    
##### 6

    python manage.py runserver







